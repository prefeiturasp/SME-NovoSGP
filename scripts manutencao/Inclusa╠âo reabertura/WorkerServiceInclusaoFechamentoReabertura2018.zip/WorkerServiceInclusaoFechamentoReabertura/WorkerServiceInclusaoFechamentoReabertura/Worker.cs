using Dapper;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WorkerServiceInclusaoFechamentoReabertura
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;

        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                Console.Write("Ano Letivo: ");
                var anoLetivo = Console.ReadLine();

                Console.Write("Inicio reabertura (YYYY-MM-DD): ");
                var inicioRebertura = Console.ReadLine();

                Console.Write("Inicio reabertura (YYYY-MM-DD): ");
                var fimReabertura = Console.ReadLine();

                var stringConexao = "User ID=postgres;Password=Z7LfhyT0XqrpZSi3;Host=10.50.1.142;Port=5432;Database=sgp_db;Pooling=true;";

                using (NpgsqlConnection connection = new NpgsqlConnection(stringConexao))
                {
                    connection.Open();

                    var sqlQuery = new StringBuilder();

                    sqlQuery.AppendLine("select distinct tc.id TipoCalendarioId,");
                    sqlQuery.AppendLine("                ue.dre_id DreId,");
                    sqlQuery.AppendLine("                ue.id UeId,");
                    sqlQuery.AppendLine("                pe.bimestre Bimestre");
                    sqlQuery.AppendLine("	from aula a");
                    sqlQuery.AppendLine("		inner join tipo_calendario tc");
                    sqlQuery.AppendLine("			on a.tipo_calendario_id = tc.id");
                    sqlQuery.AppendLine("		inner join periodo_escolar pe");
                    sqlQuery.AppendLine("			on tc.id = pe.tipo_calendario_id");
                    sqlQuery.AppendLine("		inner join turma t");
                    sqlQuery.AppendLine("			on a.turma_id = t.turma_id");
                    sqlQuery.AppendLine("		inner join ue");
                    sqlQuery.AppendLine("			on t.ue_id = ue.id");
                    sqlQuery.AppendLine($"where tc.ano_letivo = {anoLetivo} and");
                    sqlQuery.AppendLine($"	  t.ano_letivo = {anoLetivo} and");
                    sqlQuery.AppendLine("	  tc.id in (7, 8, 9) and");
                    sqlQuery.AppendLine("	  ue.tipo_escola in (1, 3, 4, 16) and");
                    sqlQuery.AppendLine("	  not a.excluido and");
                    sqlQuery.AppendLine("	  not tc.excluido;");

                    var listaDadosReabertura = await connection
                        .QueryAsync<DadosReaberturaDto>(sqlQuery.ToString(), commandTimeout: 60);

                    var contador = 1;
                    var transaction = connection.BeginTransaction();

                    foreach (var dadosReabertura in listaDadosReabertura)
                    {
                        try
                        {
                            var id = connection.ExecuteScalar($"select f_inserir_fechamento_reabertura('Ano {anoLetivo}', '{inicioRebertura}', '{fimReabertura}', {dadosReabertura.TipoCalendarioId}, {dadosReabertura.DreId}, {dadosReabertura.UeId}, null, 1, false, 'sistema', 'sistema')", transaction);
                            connection.ExecuteScalar($"select f_inserir_fechamento_reabertura_bimestre({id}, {dadosReabertura.Bimestre}, 'sistema', 'sistema')", transaction);
                            _logger.LogInformation($"{contador}/{listaDadosReabertura.Count()} - {dadosReabertura}");
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, $"Erro inclu�o abertura {dadosReabertura}");
                        }

                        contador++;
                    }

                    transaction.Commit();

                    await Task.Delay(1000, stoppingToken);
                }
            }
        }
    }
}
