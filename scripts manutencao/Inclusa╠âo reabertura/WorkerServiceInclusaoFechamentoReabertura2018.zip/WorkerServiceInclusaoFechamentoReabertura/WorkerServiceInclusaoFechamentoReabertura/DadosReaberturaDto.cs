﻿namespace WorkerServiceInclusaoFechamentoReabertura
{
    public class DadosReaberturaDto
    {
        public long TipoCalendarioId { get; set; }
        public long DreId { get; set; }
        public long UeId { get; set; }
        public int Bimestre { get; set; }
    }
}
