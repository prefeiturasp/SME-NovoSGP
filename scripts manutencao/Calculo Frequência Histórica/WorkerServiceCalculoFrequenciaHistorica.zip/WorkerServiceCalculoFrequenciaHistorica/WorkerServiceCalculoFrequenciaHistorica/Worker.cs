using Dapper;
using Microsoft.ApplicationInsights;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Npgsql;
using SME.SGP.Aplicacao.Integracoes;
using SME.SGP.Dominio.Interfaces;
using SME.SGP.Infra;
using SME.SGP.IoC;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WorkerServiceCalculoFrequenciaHistorica
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IConfiguration _configurationBuilder;        
        private readonly IServicoCalculoFrequencia _servicoCalculoFrequencia;
        public Worker(ILogger<Worker> logger, IConfiguration configuration)
        {
            _logger = logger;

            _configurationBuilder = new ConfigurationBuilder()
                .AddEnvironmentVariables()
                .Build();

            var services = new ServiceCollection()
                .AddSingleton(_configurationBuilder)
                .AddHttpContextAccessor();

            services.AddHttpClient<IServicoEol, ServicoEOL>(c =>
            {
                c.BaseAddress = new Uri(_configurationBuilder.GetSection("UrlApiEOL").Value);
                c.DefaultRequestHeaders.Add("Accept", "application/json");
                c.DefaultRequestHeaders.Add("x-api-eol-key", _configurationBuilder.GetSection("ApiKeyEolApi").Value);
            });

            RegistraDependencias.Registrar(services);

            services
                .AddSingleton<IServicoLog>(new ServicoLog(_configurationBuilder, new TelemetryClient()));

            var serviceProvider = services.BuildServiceProvider();
            services.AdicionarRedis(_configurationBuilder, serviceProvider.GetService<IServicoLog>());

            serviceProvider = services.BuildServiceProvider();
            _servicoCalculoFrequencia = serviceProvider.GetService<IServicoCalculoFrequencia>();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                Console.Write("Ano Letivo: ");
                var anoLetivo = Console.ReadLine();

                Console.Write("DRE: ");
                var dre = Console.ReadLine();

                Console.Write("Bimestre: ");
                var bimestre = Console.ReadLine();

                Console.Write("Turma: ");
                var turmaConsiderada = Console.ReadLine();

                Console.Write("Disciplina: ");
                var disciplinaConsiderada = Console.ReadLine();

                var stringConexao = "User ID=postgres;Password=Z7LfhyT0XqrpZSi3;Host=10.50.1.142;Port=5432;Database=sgp_db;Pooling=true;";

                using (NpgsqlConnection connection = new NpgsqlConnection(stringConexao))
                {
                    {
                        var query = new StringBuilder();

                        query.AppendLine("select distinct dre.dre_id DreId,");
                        query.AppendLine("                t.turma_id TurmaId,");
                        query.AppendLine("                a.disciplina_id DisciplinaId,");
                        query.AppendLine("                ra.codigo_aluno CodigoAluno,");
                        query.AppendLine("                max(a.data_aula) DataUltimaAulaBimestre");
                        query.AppendLine("	from registro_frequencia rf");
                        query.AppendLine("      inner join registro_ausencia_aluno ra");
                        query.AppendLine("          on rf.id = ra.registro_frequencia_id");
                        query.AppendLine("		inner join aula a");
                        query.AppendLine("			on rf.aula_id = a.id");
                        query.AppendLine("		inner join turma t");
                        query.AppendLine("			on a.turma_id = t.turma_id");
                        query.AppendLine("		inner join tipo_calendario tc");
                        query.AppendLine("			on a.tipo_calendario_id = tc.id");
                        query.AppendLine("		inner join periodo_escolar pe");
                        query.AppendLine("			on tc.id = pe.tipo_calendario_id and");
                        query.AppendLine($"			   pe.bimestre = {bimestre}");
                        query.AppendLine("		inner join ue");
                        query.AppendLine("			on t.ue_id = ue.id");
                        query.AppendLine("		inner join dre");
                        query.AppendLine("			on ue.dre_id = dre.id");
                        query.AppendLine("where rf.migrado and");
                        query.AppendLine($"	t.ano_letivo = {anoLetivo}	and");
                        query.AppendLine("	a.data_aula between pe.periodo_inicio and pe.periodo_fim and");
                        query.AppendLine($"	dre.dre_id = '{dre}' and");
                        if (!string.IsNullOrWhiteSpace(turmaConsiderada))
                            query.AppendLine($"	t.turma_id = '{turmaConsiderada}' and");
                        if (!string.IsNullOrWhiteSpace(disciplinaConsiderada))
                            query.AppendLine($"	a.disciplina_id = '{disciplinaConsiderada}' and");
                        query.AppendLine("	not exists (select 1");
                        query.AppendLine("				from frequencia_aluno fa");
                        query.AppendLine("			    where fa.turma_id = t.turma_id and");
                        query.AppendLine("			    	  fa.disciplina_id = a.disciplina_id and");
                        query.AppendLine("			    	  fa.codigo_aluno = ra.codigo_aluno and");
                        query.AppendLine("                    fa.bimestre = pe.bimestre and");
                        query.AppendLine("                    fa.periodo_inicio::date = pe.periodo_inicio::date and");
                        query.AppendLine("                    fa.periodo_fim::date = pe.periodo_fim::date)");
                        query.AppendLine("group by dre.dre_id,");
                        query.AppendLine("		   t.turma_id,");
                        query.AppendLine("		   a.disciplina_id,");
                        query.AppendLine("		   ra.codigo_aluno");
                        query.AppendLine("order by 1, 2, 3, 4, 5;");                        

                        _logger.LogInformation($"Inicio processamento: {DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")} - Ano: {anoLetivo} - DRE: {dre} - Bimestre: {bimestre}");

                        var dadosRegistroFrequencia = await connection
                            .QueryAsync<DadosRegistroFrequencia>(query.ToString());
                        var frequenciasCalculo = dadosRegistroFrequencia.ToList();

                        var sw = new Stopwatch();

                        var alunos = new List<string>();

                        for (int i = 0; i < frequenciasCalculo.Count; i++)
                        {
                            var turma = frequenciasCalculo[i].TurmaId;
                            var disciplina = frequenciasCalculo[i].DisciplinaId;

                            if ((frequenciasCalculo.Count > i + 1) && frequenciasCalculo[i + 1].TurmaId.Equals(turma) && frequenciasCalculo[i + 1].DisciplinaId.Equals(disciplina))
                                alunos.Add(frequenciasCalculo[i].CodigoAluno);
                            else
                            {
                                alunos.Add(frequenciasCalculo[i].CodigoAluno);

                                var dataUltimaAula = dadosRegistroFrequencia
                                    .Where(x => x.TurmaId.Equals(turma) && x.DisciplinaId.Equals(disciplina))
                                    .OrderBy(x => x.DataUltimaAulaBimestre).Last().DataUltimaAulaBimestre;
                                try
                                {
                                    sw.Reset();
                                    sw.Start();

                                    await _servicoCalculoFrequencia.CalcularFrequenciaPorTurma(alunos.ToArray(), dataUltimaAula, turma, disciplina);

                                    sw.Stop();                                    
                                    _logger.LogInformation($"Turma: {turma} - Disciplina: {disciplina} / {(int)sw.Elapsed.TotalSeconds} seg {DateTime.Now.ToString("HH:mm:ss")}");

                                    alunos.Clear();
                                }
                                catch (Exception ex)
                                {
                                    _logger.LogError($"Erro ({turma} - {dataUltimaAula} - {disciplina}): {ex}");                                    
                                }
                            }
                        }
                    }
                    
                    _logger.LogInformation($"Fim processamento: {DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")} - Ano: {anoLetivo} - DRE: {dre} - Bimestre: {bimestre}");                    
                }
                
                await Task.Delay(1000, stoppingToken);
            }
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            return base.StopAsync(cancellationToken);
        }
    }
}
