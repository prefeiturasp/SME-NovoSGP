using Dapper;
using Microsoft.ApplicationInsights;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Npgsql;
using SME.SGP.Aplicacao;
using SME.SGP.Aplicacao.Integracoes;
using SME.SGP.Dominio;
using SME.SGP.Dominio.Interfaces;
using SME.SGP.Infra;
using SME.SGP.IoC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WorkerServiceCalculoFrequenciaHistorica
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IConfiguration _configurationBuilder;
        private readonly IRepositorioRegistroAusenciaAluno repositorioRegistroAusenciaAluno;
        private readonly IRepositorioCompensacaoAusenciaAluno repositorioCompensacaoAusenciaAluno;
        private readonly IRepositorioFrequenciaAlunoDisciplinaPeriodo repositorioFrequenciaAlunoDisciplinaPeriodo;
        public Worker(ILogger<Worker> logger, IConfiguration configuration)
        {
            _logger = logger;

            _configurationBuilder = new ConfigurationBuilder()
                .AddEnvironmentVariables()
                .Build();

            var services = new ServiceCollection()
                .AddSingleton(_configurationBuilder)
                .AddHttpContextAccessor();

            services.AddHttpClient<IServicoEol, ServicoEOL>(c =>
            {
                c.BaseAddress = new Uri(_configurationBuilder.GetSection("UrlApiEOL").Value);
                c.DefaultRequestHeaders.Add("Accept", "application/json");
                c.DefaultRequestHeaders.Add("x-api-eol-key", _configurationBuilder.GetSection("ApiKeyEolApi").Value);
            });

            RegistraDependencias.Registrar(services);

            services
                .AddSingleton<IServicoLog>(new ServicoLog(_configurationBuilder, new TelemetryClient()));

            services.AddMemoryCache();

            var serviceProvider = services.BuildServiceProvider();

            repositorioRegistroAusenciaAluno = serviceProvider.GetService<IRepositorioRegistroAusenciaAluno>();
            repositorioCompensacaoAusenciaAluno = serviceProvider.GetService<IRepositorioCompensacaoAusenciaAluno>();
            repositorioFrequenciaAlunoDisciplinaPeriodo = serviceProvider.GetService<IRepositorioFrequenciaAlunoDisciplinaPeriodo>();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                Console.Write("Ano Letivo: ");
                var anoLetivo = Convert.ToInt32(Console.ReadLine());

                Console.Write("DRE: ");
                var dre = Console.ReadLine();

                Console.Write("Bimestres: ");
                var bimestres = Console.ReadLine().Split(",").Select(x => Convert.ToInt32(x));

                var stringConexao = "User ID=dev;Password=dev.AMcom;Host=10.50.1.142;Port=5432;Database=sgp_db;Pooling=true;";

                var connection = new NpgsqlConnection(stringConexao);
                var query = new StringBuilder();

                query.AppendLine("select raa.codigo_aluno CodigoAluno,");
                query.AppendLine("		 t.turma_id TurmaId,");
                query.AppendLine("		 dre.dre_id DreId,");
                query.AppendLine("		 a.disciplina_id DisciplinaId,");
                query.AppendLine("		 pe.id periodo_escolar_id,");
                query.AppendLine("		 max(a.data_aula) DataAula");
                query.AppendLine("  from registro_frequencia rf");
                query.AppendLine("		inner join registro_ausencia_aluno raa");
                query.AppendLine("			on rf.id = raa.registro_frequencia_id");
                query.AppendLine("		inner join aula a");
                query.AppendLine("			on rf.aula_id = a.id");
                query.AppendLine("		inner join tipo_calendario tc");
                query.AppendLine("			on a.tipo_calendario_id = tc.id");
                query.AppendLine("		inner join periodo_escolar pe");
                query.AppendLine("			on tc.id = pe.tipo_calendario_id");
                query.AppendLine("		inner join turma t");
                query.AppendLine("			on a.turma_id = t.turma_id");
                query.AppendLine("		inner join ue");
                query.AppendLine("			on t.ue_id = ue.id");
                query.AppendLine("		inner join dre");
                query.AppendLine("			on ue.dre_id = dre.id");
                query.AppendLine("where not raa.excluido and");
                query.AppendLine("	    t.ano_letivo = @anoLetivo and");
                query.AppendLine("		tc.ano_letivo = @anoLetivo and");
                query.AppendLine("		pe.bimestre = @bimestre and");
                query.AppendLine("		a.data_aula::date between pe.periodo_inicio::date and pe.periodo_fim::date and");
                query.AppendLine("		dre.dre_id = @dre");
                query.AppendLine("group by raa.codigo_aluno,");
                query.AppendLine("		   t.turma_id,");
                query.AppendLine("		   dre.dre_id,");
                query.AppendLine("		   a.disciplina_id,");
                query.AppendLine("		   pe.id;");

                foreach (var bimestre in bimestres)
                {
                    _logger.LogInformation($"Inicio processamento: {DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")} - Ano: {anoLetivo} - DRE: {dre} - Bimestre: {bimestre}");

                    var dadosRegistroFrequencia = await connection
                    .QueryAsync<DadosRegistroFrequencia>(query.ToString(), new
                    {
                        anoLetivo,
                        dre,
                        bimestre
                    }, commandTimeout: 300);

                    var frequenciasCalculo = dadosRegistroFrequencia.ToList();                                        

                    var sw = new Stopwatch();

                    var alunos = new List<string>();

                    for (int i = 0; i < frequenciasCalculo.Count; i++)
                    {
                        var turma = frequenciasCalculo[i].TurmaId;
                        var disciplina = frequenciasCalculo[i].DisciplinaId;

                        if ((frequenciasCalculo.Count > i + 1) && frequenciasCalculo[i + 1].TurmaId.Equals(turma) && frequenciasCalculo[i + 1].DisciplinaId.Equals(disciplina))
                            alunos.Add(frequenciasCalculo[i].CodigoAluno);
                        else
                        {
                            alunos.Add(frequenciasCalculo[i].CodigoAluno);

                            var dataUltimaAula = dadosRegistroFrequencia
                                .Where(x => x.TurmaId.Equals(turma) && x.DisciplinaId.Equals(disciplina))
                                .OrderBy(x => x.DataAula).Last().DataAula;
                            try
                            {
                                sw.Reset();
                                sw.Start();

                                var totalAulasNaDisciplina = repositorioRegistroAusenciaAluno.ObterTotalAulasPorDisciplinaETurma(dataUltimaAula, disciplina, turma);
                                var totalAulasDaTurmaGeral = repositorioRegistroAusenciaAluno.ObterTotalAulasPorDisciplinaETurma(dataUltimaAula, string.Empty, turma);

                                foreach (var codigoAluno in alunos)
                                {
                                    await RegistraFrequenciaPorDisciplina(turma, disciplina, dataUltimaAula, totalAulasNaDisciplina, codigoAluno);
                                    await RegistraFrequenciaGeral(turma, dataUltimaAula, codigoAluno, totalAulasDaTurmaGeral);
                                }

                                sw.Stop();
                                _logger.LogInformation($"Ano: {anoLetivo} - DRE: {dre} - Bimestre: {bimestre} - Turma: {turma} - Disciplina: {disciplina} / {(int)sw.Elapsed.TotalSeconds} seg {DateTime.Now.ToString("HH:mm:ss")}");

                                alunos.Clear();
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError($"Erro ({turma} - {dataUltimaAula} - {disciplina}): {ex}");
                            }
                        }
                    }

                    _logger.LogInformation($"Fim processamento: {DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")} - Ano: {anoLetivo} - DRE: {dre} - Bimestre: {bimestre}");
                }

                if (connection.State == ConnectionState.Open)
                    await connection.CloseAsync();

                await connection.DisposeAsync();

                await Task.Delay(1000, stoppingToken);
            }
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            return base.StopAsync(cancellationToken);
        }

        private async Task RegistraFrequenciaPorDisciplina(string turmaId, string disciplinaId, DateTime dataAtual, int totalAulasNaDisciplina, string codigoAluno)
        {
            var ausenciasAlunoPorDisciplina = repositorioRegistroAusenciaAluno.ObterTotalAusenciasPorAlunoETurma(dataAtual, codigoAluno, disciplinaId, turmaId);
            if (ausenciasAlunoPorDisciplina != null)
            {
                var totalCompensacoesDisciplinaAluno = repositorioCompensacaoAusenciaAluno.ObterTotalCompensacoesPorAlunoETurma(ausenciasAlunoPorDisciplina.Bimestre, codigoAluno, disciplinaId, turmaId);
                var frequenciaAluno = MapearFrequenciaAluno(codigoAluno,
                                                            turmaId,
                                                            disciplinaId,
                                                            ausenciasAlunoPorDisciplina.PeriodoEscolarId,
                                                            ausenciasAlunoPorDisciplina.PeriodoInicio,
                                                            ausenciasAlunoPorDisciplina.PeriodoFim,
                                                            ausenciasAlunoPorDisciplina.Bimestre,
                                                            ausenciasAlunoPorDisciplina.TotalAusencias,
                                                            totalAulasNaDisciplina,
                                                            totalCompensacoesDisciplinaAluno,
                                                            TipoFrequenciaAluno.PorDisciplina);

                if (frequenciaAluno.TotalAusencias > 0)
                    await repositorioFrequenciaAlunoDisciplinaPeriodo.SalvarAsync(frequenciaAluno);
                else
                if (frequenciaAluno.Id > 0)
                    repositorioFrequenciaAlunoDisciplinaPeriodo.Remover(frequenciaAluno);
            }
            else
            {
                var frequenciaAluno = repositorioFrequenciaAlunoDisciplinaPeriodo.ObterPorAlunoData(codigoAluno, dataAtual, TipoFrequenciaAluno.PorDisciplina, disciplinaId);

                if (frequenciaAluno != null)
                    repositorioFrequenciaAlunoDisciplinaPeriodo.Remover(frequenciaAluno);
            }
        }

        private async Task RegistraFrequenciaGeral(string turmaId, DateTime dataAtual, string codigoAluno, int totalAulasDaTurma)
        {
            var totalAusenciasGeralAluno = repositorioRegistroAusenciaAluno.ObterTotalAusenciasPorAlunoETurma(dataAtual, codigoAluno, string.Empty, turmaId);
            if (totalAusenciasGeralAluno != null)
            {
                var totalCompensacoesGeralAluno = repositorioCompensacaoAusenciaAluno.ObterTotalCompensacoesPorAlunoETurma(totalAusenciasGeralAluno.Bimestre, codigoAluno, string.Empty, turmaId);
                var frequenciaGeralAluno = MapearFrequenciaAluno(codigoAluno,
                                                                    turmaId,
                                                                    string.Empty,
                                                                    totalAusenciasGeralAluno.PeriodoEscolarId,
                                                                    totalAusenciasGeralAluno.PeriodoInicio,
                                                                    totalAusenciasGeralAluno.PeriodoFim,
                                                                    totalAusenciasGeralAluno.Bimestre,
                                                                    totalAusenciasGeralAluno.TotalAusencias,
                                                                    totalAulasDaTurma,
                                                                    totalCompensacoesGeralAluno,
                                                                    TipoFrequenciaAluno.Geral);

                if (frequenciaGeralAluno.PercentualFrequencia < 100)
                    await repositorioFrequenciaAlunoDisciplinaPeriodo.SalvarAsync(frequenciaGeralAluno);
                else
                if (frequenciaGeralAluno.Id > 0)
                    repositorioFrequenciaAlunoDisciplinaPeriodo.Remover(frequenciaGeralAluno);
            }
            else
            {
                var frequenciaAluno = repositorioFrequenciaAlunoDisciplinaPeriodo.ObterPorAlunoData(codigoAluno, dataAtual, TipoFrequenciaAluno.Geral);

                if (frequenciaAluno != null)
                    repositorioFrequenciaAlunoDisciplinaPeriodo.Remover(frequenciaAluno);
            }
        }

        private FrequenciaAluno MapearFrequenciaAluno(string codigoAluno, string turmaId, string disciplinaId, long? periodoEscolarId, DateTime periodoInicio, DateTime periodoFim, int bimestre, int totalAusencias, int totalAulas, int totalCompensacoes, TipoFrequenciaAluno tipo)
        {
            var frequenciaAluno = repositorioFrequenciaAlunoDisciplinaPeriodo.Obter(codigoAluno, disciplinaId, periodoEscolarId.Value, tipo, turmaId);
            return frequenciaAluno == null ?
            new FrequenciaAluno
                         (
                             codigoAluno,
                             turmaId,
                             disciplinaId,
                             periodoEscolarId,
                             periodoInicio,
                             periodoFim,
                             bimestre,
                             totalAusencias,
                             totalAulas,
                             totalCompensacoes,
                             tipo
                         ) : frequenciaAluno.DefinirFrequencia(totalAusencias, totalAulas, totalCompensacoes, tipo);
        }
    }
}
