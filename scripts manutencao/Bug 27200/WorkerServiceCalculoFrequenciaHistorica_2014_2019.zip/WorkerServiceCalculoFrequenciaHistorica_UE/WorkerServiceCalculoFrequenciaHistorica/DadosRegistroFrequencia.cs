﻿using System;

namespace WorkerServiceCalculoFrequenciaHistorica
{
    public class DadosRegistroFrequencia
    {
        public string TurmaId { get; set; }
        public string DisciplinaId { get; set; }
        public string CodigoAluno { get; set; }
        public DateTime DataAula { get; set; }
    }
}
