﻿namespace WorkerServiceAjusteFechamentoTurmaDisciplina
{
    public class DreDto
    {
        public long Id { get; set; }
        public string DreId { get; set; }
    }
}
