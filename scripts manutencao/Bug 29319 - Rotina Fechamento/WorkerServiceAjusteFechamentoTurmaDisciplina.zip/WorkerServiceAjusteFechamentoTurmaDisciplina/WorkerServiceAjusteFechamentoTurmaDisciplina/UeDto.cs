﻿namespace WorkerServiceAjusteFechamentoTurmaDisciplina
{
    public class UeDto
    {
        public long Id { get; set; }
        public string UeId { get; set; }
    }
}
