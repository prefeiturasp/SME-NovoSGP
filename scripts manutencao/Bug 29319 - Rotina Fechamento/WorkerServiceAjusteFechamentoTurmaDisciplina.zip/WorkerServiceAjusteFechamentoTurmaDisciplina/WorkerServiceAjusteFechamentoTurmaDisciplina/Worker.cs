using Dapper;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WorkerServiceAjusteFechamentoTurmaDisciplina
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;

        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                Console.Write("Ano Letivo: ");
                var anoLetivo = Console.ReadLine();

                Console.Write("DRE: ");
                var codigoDre = Console.ReadLine();

                var stringConexao = "User ID=postgres;Password=Z7LfhyT0XqrpZSi3;Host=10.50.1.142;Port=5432;Database=sgp_db;Pooling=true;";

                using (NpgsqlConnection connection = new NpgsqlConnection(stringConexao))
                {
                    var sqlQuery = new StringBuilder();
                    sqlQuery.AppendLine($"select id, dre_id DreId from dre where dre_id = '{codigoDre}';");

                    var sqlQueryPrincipal = new StringBuilder();
                    sqlQueryPrincipal.AppendLine("select distinct 'update fechamento_nota set fechamento_aluno_id = (f_inserir_fechamento_aluno_migrado(f_inserir_fechamento_turma_disciplina_migrado(' || fn.disciplina_id || ', ' || ft.id || '), ''' || fa.aluno_codigo || ''')) where id = ' || fn.id || ';'");
                    sqlQueryPrincipal.AppendLine("	from turma t");
                    sqlQueryPrincipal.AppendLine("		inner join ue");
                    sqlQueryPrincipal.AppendLine("			on t.ue_id = ue.id");
                    sqlQueryPrincipal.AppendLine("		inner join dre");
                    sqlQueryPrincipal.AppendLine("			on ue.dre_id = dre.id");
                    sqlQueryPrincipal.AppendLine("		inner join fechamento_turma ft");
                    sqlQueryPrincipal.AppendLine("			on t.id = ft.turma_id");
                    sqlQueryPrincipal.AppendLine("		inner join fechamento_turma_disciplina ftd");
                    sqlQueryPrincipal.AppendLine("			on ft.id = ftd.fechamento_turma_id");
                    sqlQueryPrincipal.AppendLine("		inner join fechamento_aluno fa");
                    sqlQueryPrincipal.AppendLine("			on ftd.id = fa.fechamento_turma_disciplina_id");
                    sqlQueryPrincipal.AppendLine("		inner join fechamento_nota fn");
                    sqlQueryPrincipal.AppendLine("			on fa.id = fn.fechamento_aluno_id and");
                    sqlQueryPrincipal.AppendLine("			   ftd.disciplina_id <> fn.disciplina_id");
                    sqlQueryPrincipal.AppendLine("		inner join componente_curricular cc");
                    sqlQueryPrincipal.AppendLine("			on ftd.disciplina_id = cc.id");
                    sqlQueryPrincipal.AppendLine($"where t.ano_letivo = {anoLetivo} and");
                    sqlQueryPrincipal.AppendLine($"	    ue.id = @ueId and");
                    sqlQueryPrincipal.AppendLine("	    fn.id is not null and");
                    sqlQueryPrincipal.AppendLine("	    not cc.eh_regencia and");
                    sqlQueryPrincipal.AppendLine("	    not ft.excluido and");
                    sqlQueryPrincipal.AppendLine("	    not ftd.excluido and");
                    sqlQueryPrincipal.AppendLine("       t.ano between '1' and '9' and");
                    sqlQueryPrincipal.AppendLine("       not (t.ano between '1' and '5' and t.modalidade_codigo = 5 and t.qt_duracao_aula = 4);");

                    var dre = await connection
                        .QueryFirstOrDefaultAsync<DreDto>(sqlQuery.ToString());

                    var sw = new Stopwatch();

                    sqlQuery.Clear();
                    sqlQuery.Append($"select id, ue_id UeId from ue where dre_id = {dre.Id};");

                    var ues = await connection
                        .QueryAsync<UeDto>(sqlQuery.ToString());

                    foreach (var ue in ues)
                    {
                        sw.Reset();
                        sw.Start();

                        var scripts = await connection
                            .QueryAsync<string>(sqlQueryPrincipal.ToString(), new { ueId = ue.Id });

                        var contador = 1;
                        var total = scripts.Count();

                        foreach (var script in scripts)
                        {
                            try
                            {
                                await connection.ExecuteAsync(script);
                                _logger.LogInformation($"Fechamento atualizado ({contador}/{total} - {dre.DreId} - {ue.UeId}) : {script}");
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, $"Erro fechamento {script}");
                            }

                            contador++;
                        }

                        sw.Stop();
                        Console.WriteLine($"DRE: {dre.DreId} - UE: {ue.UeId} - Total: {total} - Tempo: {sw.Elapsed.Seconds} seg");
                    }
                }

                await Task.Delay(1000, stoppingToken);
            }
        }
    }
}
