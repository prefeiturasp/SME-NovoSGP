﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UpdateAulaAtividadeAvaliativaSGP
{
    public class TurmaDto
    {
        public string CodigoTurma { get; set; }
    }
}
