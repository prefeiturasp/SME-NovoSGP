using Dapper;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace UpdateAulaAtividadeAvaliativaSGP
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly ConnectionStrings _connectionStrings;

        public Worker(ILogger<Worker> logger, IOptions<ConnectionStrings> connectionStrings)
        {
            _logger = logger;
            _connectionStrings = connectionStrings != null ? connectionStrings.Value : throw new System.ArgumentNullException(nameof(connectionStrings));
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                Console.Write("Ano Letivo: ");
                var anoLetivo = Console.ReadLine();

                try
                {

                    var stringConexaoD1 = _connectionStrings.EolConnection;
                    string stringConexaoSgp = _connectionStrings.SGPPostgresProd;

                    using (NpgsqlConnection connectionSGP = new NpgsqlConnection(stringConexaoSgp))
                    {

                        await connectionSGP.OpenAsync();
                        int erros = 0;
                        int turmasAlteradas = 0;

                        var listaTurmas = await connectionSGP.QueryAsync<TurmaDto>(QueriesSGP.ObterTurmasAulaComponente.ToString(),
                            new { anoLevito = Convert.ToInt32(anoLetivo), codigoComponente = "1046" });

                        foreach (var turma in listaTurmas)
                        {
                            string codTurma = turma.CodigoTurma;
                            var transaction = connectionSGP.BeginTransaction();
                            try
                            {
                                using (SqlConnection connectionD1 = new SqlConnection(stringConexaoD1))
                                {
                                    var listaCodComponenteEOL = await connectionD1
                                        .QueryAsync<ComponenteCurricularDto>(QueriesEOL.ObterComponenteCurricularTurma.ToString(),
                                        new { codigoTurma = codTurma, anoLevito = anoLetivo });

                                    if (listaCodComponenteEOL != null && listaCodComponenteEOL.Any())
                                    {
                                        Console.WriteLine("Turma: " + codTurma);
                                        await connectionSGP.ExecuteScalarAsync(QueriesSGP.UpdateAulas, new { codigoTurma = codTurma });
                                        await connectionSGP.ExecuteScalarAsync(QueriesSGP.UpdateAtividadesAvaliativas, new { codigoTurma = codTurma });
                                        await connectionSGP.ExecuteScalarAsync(QueriesSGP.DeleteTempCodTurma, new { codigoTurma = Convert.ToInt32(codTurma) });
                                        turmasAlteradas++;
                                    }
                                }
                                if (transaction != null)
                                    transaction.Commit();
                            }
                            catch (Exception e)
                            {
                                if (transaction != null)
                                    transaction.Rollback();
                                NotificarErro(e, $"**Erro** TURMA: {codTurma}, EX({e.Message}).");
                                erros++;
                                await Task.Delay(1000, stoppingToken);
                            }
                        }

                        Notificar($"Ano Letivo: {anoLetivo}");
                        Notificar($"Turmas verificadas: {listaTurmas.ToList().Count}");
                        Notificar($"Turmas alteradas: {turmasAlteradas}");
                        Notificar($"Erros: {erros}");

                    }

                    await Task.Delay(1000, stoppingToken);

                }
                catch (Exception e)
                {
                    NotificarErro(e, "Erro: " + e.Message);
                    await Task.Delay(1000, stoppingToken);
                }
            }
        }

        private void NotificarErro(Exception ex, string erro)
        {
            Console.WriteLine(erro);
            _logger.LogError(ex, erro);
        }

        private void Notificar(string msg)
        {
            Console.WriteLine(msg);
            _logger.LogInformation(msg);
        }

    }
}
