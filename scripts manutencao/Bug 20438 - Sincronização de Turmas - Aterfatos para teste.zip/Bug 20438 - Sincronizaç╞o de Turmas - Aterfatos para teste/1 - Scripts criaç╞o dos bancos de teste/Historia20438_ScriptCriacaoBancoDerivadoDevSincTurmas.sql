create database sgp_db-dev_teste_sync_turmas;

---- DRE
CREATE TABLE public.dre (
	id int8 NOT NULL,
	dre_id varchar(15) NULL,
	abreviacao varchar(10) NULL,
	nome varchar(100) NULL,
	data_atualizacao date NOT NULL,
	CONSTRAINT dre_pk PRIMARY KEY (id)
);
CREATE INDEX dre_dre_id_idx ON public.dre USING btree (dre_id);

---- UE
CREATE TABLE public.ue (
	id int8 NOT NULL,
	ue_id varchar(15) NULL,
	dre_id int8 NULL,
	nome varchar(200) NULL,
	tipo_escola int2 NULL,
	data_atualizacao date NOT NULL,
	CONSTRAINT ue_pk PRIMARY KEY (id)
);
CREATE INDEX ue_dre_idx ON public.ue USING btree (dre_id);
CREATE INDEX ue_ue_id_idx ON public.ue USING btree (ue_id);
CREATE INDEX ue_ue_idx ON public.ue USING btree (ue_id);

-- public.ue foreign keys
ALTER TABLE public.ue ADD CONSTRAINT ue_dre_id_fk FOREIGN KEY (dre_id) REFERENCES dre(id) ON DELETE CASCADE;

---- TURMA
CREATE TABLE public.turma (
	id int8 NOT NULL,
	turma_id varchar(15) NULL,
	ue_id int8 NULL,
	nome varchar(10) NULL,
	ano bpchar(1) NULL,
	ano_letivo int4 NULL,
	modalidade_codigo int4 NULL,
	semestre int4 NULL,
	qt_duracao_aula int2 NULL,
	tipo_turno int2 NULL,
	data_atualizacao date NOT NULL,
	historica bool NOT NULL DEFAULT false,
	dt_fim_eol date NULL,
	ensino_especial bool NULL DEFAULT false,
	etapa_eja int4 NULL,
	CONSTRAINT turma_pk PRIMARY KEY (id)
);
CREATE INDEX turma_historica_idx ON public.turma USING btree (historica, dt_fim_eol);
CREATE INDEX turma_modalidade_idx ON public.turma USING btree (modalidade_codigo);
CREATE INDEX turma_turma_id_idx ON public.turma USING btree (turma_id);
CREATE INDEX turma_ue_idx ON public.turma USING btree (ue_id);

-- public.turma foreign keys
ALTER TABLE public.turma ADD CONSTRAINT turma_ue_id_fk FOREIGN KEY (ue_id) REFERENCES ue(id) ON DELETE CASCADE;

---- PERIODO_ESCOLAR
CREATE TABLE public.periodo_escolar (
	id int8 NOT NULL,
	tipo_calendario_id int8 NOT NULL,
	bimestre int4 NOT NULL,
	periodo_inicio timestamp NOT NULL,
	periodo_fim timestamp NOT NULL,
	alterado_por varchar(200) NULL,
	alterado_rf varchar(200) NULL,
	alterado_em timestamp NULL,
	criado_por varchar(200) NOT NULL,
	criado_rf varchar(200) NOT NULL,
	criado_em timestamp NOT NULL,
	migrado bool NOT NULL DEFAULT false,
	CONSTRAINT periodo_escolar_pk PRIMARY KEY (id)
);

---- FECHAMENTO_TURMA
CREATE TABLE public.fechamento_turma (
	id int8 NOT NULL,
	turma_id int8 NOT NULL,
	periodo_escolar_id int8 NULL,
	migrado bool NOT NULL DEFAULT false,
	excluido bool NOT NULL DEFAULT false,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	CONSTRAINT fechamento_turma_pk PRIMARY KEY (id)
);
CREATE INDEX fechamento_turma_periodo_idx ON public.fechamento_turma USING btree (periodo_escolar_id);
CREATE INDEX fechamento_turma_turma_idx ON public.fechamento_turma USING btree (turma_id);

-- public.fechamento_turma foreign keys
ALTER TABLE public.fechamento_turma ADD CONSTRAINT fechamento_turma_periodo_fk FOREIGN KEY (periodo_escolar_id) REFERENCES periodo_escolar(id);
ALTER TABLE public.fechamento_turma ADD CONSTRAINT fechamento_turma_turma_fk FOREIGN KEY (turma_id) REFERENCES turma(id);

---- CONSELHO_CLASSE
CREATE TABLE public.conselho_classe (
	id int8 NOT NULL,
	fechamento_turma_id int8 NOT NULL,
	migrado bool NOT NULL DEFAULT false,
	excluido bool NOT NULL DEFAULT false,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	CONSTRAINT conselho_classe_pk PRIMARY KEY (id)
);
CREATE INDEX conselho_classe_fechamento_idx ON public.conselho_classe USING btree (fechamento_turma_id);

-- public.conselho_classe foreign keys
ALTER TABLE public.conselho_classe ADD CONSTRAINT conselho_classe_fechamento_fk FOREIGN KEY (fechamento_turma_id) REFERENCES fechamento_turma(id);

---- CONSELHO_CLASSE_PARECER
CREATE TABLE public.conselho_classe_parecer (
	id int8 NOT NULL,
	nome varchar(200) NOT NULL,
	aprovado bool NOT NULL DEFAULT false,
	frequencia bool NOT NULL DEFAULT false,
	conselho bool NOT NULL DEFAULT false,
	inicio_vigencia timestamp NOT NULL,
	fim_vigencia timestamp NULL,
	criado_por varchar(200) NOT NULL,
	criado_rf varchar(20) NOT NULL,
	criado_em timestamp NOT NULL,
	alterado_por varchar(200) NULL,
	alterado_rf varchar(20) NULL,
	alterado_em timestamp NULL,
	nota bool NOT NULL DEFAULT false,
	CONSTRAINT conselho_classe_parecer_pkey PRIMARY KEY (id)
);

---- CONSELHO_CLASSE_ALUNO
CREATE TABLE public.conselho_classe_aluno (
	id int8 NOT NULL,
	conselho_classe_id int8 NOT NULL,
	aluno_codigo varchar(15) NOT NULL,
	recomendacoes_aluno varchar NULL,
	recomendacoes_familia varchar NULL,
	anotacoes_pedagogicas varchar NULL,
	migrado bool NOT NULL DEFAULT false,
	excluido bool NOT NULL DEFAULT false,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	conselho_classe_parecer_id int8 NULL,
	CONSTRAINT conselho_classe_aluno_pk PRIMARY KEY (id)
);
CREATE INDEX conselho_classe_aluno_conselho_idx ON public.conselho_classe_aluno USING btree (conselho_classe_id);

-- public.conselho_classe_aluno foreign keys
ALTER TABLE public.conselho_classe_aluno ADD CONSTRAINT conselho_classe_aluno_conselho_fk FOREIGN KEY (conselho_classe_id) REFERENCES conselho_classe(id);
ALTER TABLE public.conselho_classe_aluno ADD CONSTRAINT conselho_classe_aluno_parecer_fk FOREIGN KEY (conselho_classe_parecer_id) REFERENCES conselho_classe_parecer(id);

---- CONCEITO_VALORES
CREATE TABLE public.conceito_valores (
	id int8 NOT NULL,
	valor varchar(50) NOT NULL,
	descricao varchar(200) NOT NULL,
	aprovado bool NOT NULL DEFAULT true,
	ativo bool NOT NULL DEFAULT true,
	inicio_vigencia timestamp NOT NULL,
	fim_vigencia timestamp NULL,
	criado_por varchar(200) NOT NULL,
	criado_rf varchar(200) NOT NULL,
	criado_em timestamp NOT NULL,
	alterado_por varchar(200) NULL,
	alterado_rf varchar(200) NULL,
	alterado_em timestamp NULL,
	CONSTRAINT conceito_valores_pk PRIMARY KEY (id)
);
CREATE INDEX conceito_valores_valor_idx ON public.conceito_valores USING btree (valor);
CREATE INDEX sintese_valores_valor_idx ON public.conceito_valores USING btree (valor);

---- CONSELHO_CLASSE_NOTA
CREATE TABLE public.conselho_classe_nota (
	id int8 NOT NULL,
	conselho_classe_aluno_id int8 NOT NULL,
	componente_curricular_codigo int8 NOT NULL,
	nota numeric(5,2) NULL,
	conceito_id int8 NULL,
	justificativa varchar NOT NULL,
	migrado bool NOT NULL DEFAULT false,
	excluido bool NOT NULL DEFAULT false,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	CONSTRAINT conselho_classe_nota_pk PRIMARY KEY (id)
);
CREATE INDEX conselho_classe_nota_aluno_idx ON public.conselho_classe_nota USING btree (conselho_classe_aluno_id);

-- public.conselho_classe_nota foreign keys
ALTER TABLE public.conselho_classe_nota ADD CONSTRAINT conselho_classe_nota_aluno_fk FOREIGN KEY (conselho_classe_aluno_id) REFERENCES conselho_classe_aluno(id);
ALTER TABLE public.conselho_classe_nota ADD CONSTRAINT conselho_classe_nota_conceito_fk FOREIGN KEY (conceito_id) REFERENCES conceito_valores(id);

---- FECHAMENTO_TURMA_DISCIPLINA
CREATE TABLE public.fechamento_turma_disciplina (
	id int8 NOT NULL,
	disciplina_id int8 NOT NULL,
	migrado bool NOT NULL DEFAULT false,
	excluido bool NOT NULL DEFAULT false,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	situacao int4 NOT NULL,
	justificativa varchar(250) NULL,
	fechamento_turma_id int8 NOT NULL,
	CONSTRAINT fechamento_turma_disciplina_pk PRIMARY KEY (id)
);
CREATE INDEX fechamento_turma_disciplina_disciplina_idx ON public.fechamento_turma_disciplina USING btree (disciplina_id);
CREATE INDEX fechamento_turma_disciplina_fechamento_idx ON public.fechamento_turma_disciplina USING btree (fechamento_turma_id);

-- public.fechamento_turma_disciplina foreign keys
ALTER TABLE public.fechamento_turma_disciplina ADD CONSTRAINT fechamento_turma_disciplina_fechamento_fk FOREIGN KEY (fechamento_turma_id) REFERENCES fechamento_turma(id);

---- FECHAMENTO_ALUNO
CREATE TABLE public.fechamento_aluno (
	id int8 NOT NULL,
	fechamento_turma_disciplina_id int8 NOT NULL,
	aluno_codigo varchar(15) NOT NULL,
	anotacao varchar NULL,
	migrado bool NOT NULL DEFAULT false,
	excluido bool NOT NULL DEFAULT false,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	CONSTRAINT fechamento_aluno_pk PRIMARY KEY (id)
);
CREATE INDEX fechamento_aluno_aluno_idx ON public.fechamento_aluno USING btree (aluno_codigo);
CREATE INDEX fechamento_aluno_fechamento_idx ON public.fechamento_aluno USING btree (fechamento_turma_disciplina_id);

-- public.fechamento_aluno foreign keys
ALTER TABLE public.fechamento_aluno ADD CONSTRAINT fechamento_aluno_fechamento_fk FOREIGN KEY (fechamento_turma_disciplina_id) REFERENCES fechamento_turma_disciplina(id);

---- SINTESE_VALORES
CREATE TABLE public.sintese_valores (
	id int8 NOT NULL,
	valor varchar(50) NOT NULL,
	descricao varchar(200) NOT NULL,
	aprovado bool NOT NULL DEFAULT true,
	ativo bool NOT NULL DEFAULT true,
	inicio_vigencia timestamp NOT NULL,
	fim_vigencia timestamp NULL,
	criado_por varchar(200) NOT NULL,
	criado_rf varchar(200) NOT NULL,
	criado_em timestamp NOT NULL,
	alterado_por varchar(200) NULL,
	alterado_rf varchar(200) NULL,
	alterado_em timestamp NULL,
	CONSTRAINT sinstese_valores_pk PRIMARY KEY (id)
);

---- FECHAMENTO_NOTA
CREATE TABLE public.fechamento_nota (
	id int8 NOT NULL,
	disciplina_id int8 NOT NULL,
	nota numeric(5,2) NULL,
	conceito_id int8 NULL,
	migrado bool NOT NULL DEFAULT false,
	excluido bool NOT NULL DEFAULT false,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	sintese_id int8 NULL,
	fechamento_aluno_id int8 NOT NULL,
	CONSTRAINT nota_conceito_bimestre_pk PRIMARY KEY (id)
);
CREATE INDEX fechamento_nota_aluno_idx ON public.fechamento_nota USING btree (fechamento_aluno_id);
CREATE INDEX nota_conceito_bimestre_disciplina_idx ON public.fechamento_nota USING btree (disciplina_id);

-- public.fechamento_nota foreign keys
ALTER TABLE public.fechamento_nota ADD CONSTRAINT fechamento_nota_aluno_fk FOREIGN KEY (fechamento_aluno_id) REFERENCES fechamento_aluno(id);
ALTER TABLE public.fechamento_nota ADD CONSTRAINT nota_conceito_bimestre_sintese_fk FOREIGN KEY (sintese_id) REFERENCES sintese_valores(id);

---- WF_APROVACAO
CREATE TABLE public.wf_aprovacao (
	id int8 NOT NULL,
	ue_id varchar(15) NULL,
	dre_id varchar(15) NULL,
	ano int4 NULL,
	turma_id varchar(15) NULL,
	notificacao_mensagem varchar NOT NULL,
	notificacao_titulo varchar(500) NOT NULL,
	notificacao_tipo int4 NOT NULL,
	notificacao_categoria int4 NOT NULL,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	tipo int4 NOT NULL DEFAULT 1,
	excluido bool NOT NULL DEFAULT false,
	CONSTRAINT wf_aprova_niveis_pk PRIMARY KEY (id)
);

---- WF_APROVACAO_NOTA_FECHAMENTO
CREATE TABLE public.wf_aprovacao_nota_fechamento (
	id int8 NOT NULL,
	wf_aprovacao_id int8 NOT NULL,
	fechamento_nota_id int8 NOT NULL,
	nota numeric(5,2) NULL,
	conceito_id int8 NULL,
	CONSTRAINT wf_aprovacao_nota_fechamento_pk PRIMARY KEY (id)
);
CREATE INDEX wf_aprovacao_nota_fechamento_aprovacao_idx ON public.wf_aprovacao_nota_fechamento USING btree (wf_aprovacao_id);
CREATE INDEX wf_aprovacao_nota_fechamento_nota_idx ON public.wf_aprovacao_nota_fechamento USING btree (fechamento_nota_id);

-- public.wf_aprovacao_nota_fechamento foreign keys
ALTER TABLE public.wf_aprovacao_nota_fechamento ADD CONSTRAINT wf_aprovacao_nota_fechamento_aprovacao_fk FOREIGN KEY (wf_aprovacao_id) REFERENCES wf_aprovacao(id);
ALTER TABLE public.wf_aprovacao_nota_fechamento ADD CONSTRAINT wf_aprovacao_nota_fechamento_conceito_fk FOREIGN KEY (conceito_id) REFERENCES conceito_valores(id);
ALTER TABLE public.wf_aprovacao_nota_fechamento ADD CONSTRAINT wf_aprovacao_nota_fechamento_nota_fk FOREIGN KEY (fechamento_nota_id) REFERENCES fechamento_nota(id);

---- PENDENCIA
CREATE TABLE public.pendencia (
	id int8 NOT NULL,
	titulo varchar(100) NOT NULL,
	descricao varchar NOT NULL,
	situacao int4 NOT NULL,
	tipo int4 NOT NULL,
	excluido bool NOT NULL DEFAULT false,
	migrado bool NOT NULL DEFAULT false,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	CONSTRAINT pendencia_pk PRIMARY KEY (id)
);

---- PENDENCIA_FECHAMENTO
CREATE TABLE public.pendencia_fechamento (
	id int8 NOT NULL,
	fechamento_turma_disciplina_id int8 NOT NULL,
	pendencia_id int8 NOT NULL,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	CONSTRAINT pendencia_fechamento_pk PRIMARY KEY (id)
);
CREATE INDEX pendencia_fechamento_fechamento_turma_id_idx ON public.pendencia_fechamento USING btree (fechamento_turma_disciplina_id);
CREATE INDEX pendencia_fechamento_pendencia_id_idx ON public.pendencia_fechamento USING btree (pendencia_id);

-- public.pendencia_fechamento foreign keys
ALTER TABLE public.pendencia_fechamento ADD CONSTRAINT pendencia_fechamento_fechamento_fk FOREIGN KEY (fechamento_turma_disciplina_id) REFERENCES fechamento_turma_disciplina(id);
ALTER TABLE public.pendencia_fechamento ADD CONSTRAINT pendencia_fechamento_pendencia_fk FOREIGN KEY (pendencia_id) REFERENCES pendencia(id);

---- COMPENSACAO_AUSENCIA
CREATE TABLE public.compensacao_ausencia (
	id int8 NOT NULL,
	bimestre int4 NOT NULL,
	disciplina_id varchar(15) NOT NULL,
	turma_id int8 NOT NULL,
	nome varchar NOT NULL,
	descricao varchar NOT NULL,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	excluido bool NOT NULL DEFAULT false,
	migrado bool NOT NULL DEFAULT false,
	ano_letivo int4 NOT NULL DEFAULT 0,
	CONSTRAINT compensacao_ausencia_pk PRIMARY KEY (id)
);
CREATE INDEX compensacao_ausencia_ano_letivo_idx ON public.compensacao_ausencia USING btree (ano_letivo);
CREATE INDEX compensacao_ausencia_disciplina_idx ON public.compensacao_ausencia USING btree (disciplina_id);
CREATE INDEX compensacao_ausencia_turma_idx ON public.compensacao_ausencia USING btree (turma_id);

-- public.compensacao_ausencia foreign keys
ALTER TABLE public.compensacao_ausencia ADD CONSTRAINT compensacao_ausencia_turma_fk FOREIGN KEY (turma_id) REFERENCES turma(id);

---- COMPENSACAO_AUSENCIA_ALUNO
CREATE TABLE public.compensacao_ausencia_aluno (
	id int8 NOT NULL,
	compensacao_ausencia_id int8 NOT NULL,
	codigo_aluno varchar(100) NOT NULL,
	qtd_faltas_compensadas int4 NOT NULL,
	notificado bool NOT NULL DEFAULT false,
	criado_em timestamp NOT NULL,
	criado_por varchar(200) NOT NULL,
	alterado_em timestamp NULL,
	alterado_por varchar(200) NULL,
	criado_rf varchar(200) NOT NULL,
	alterado_rf varchar(200) NULL,
	excluido bool NOT NULL DEFAULT false,
	migrado bool NOT NULL DEFAULT false,
	CONSTRAINT compensacao_ausencia_aluno_pk PRIMARY KEY (id)
);
CREATE INDEX compensacao_ausencia_aluno_codigo_aluno_idx ON public.compensacao_ausencia_aluno USING btree (codigo_aluno);
CREATE INDEX compensacao_ausencia_aluno_compensacao_ausencia_idx ON public.compensacao_ausencia_aluno USING btree (compensacao_ausencia_id);

-- public.compensacao_ausencia_aluno foreign keys
ALTER TABLE public.compensacao_ausencia_aluno ADD CONSTRAINT compensacao_ausencia_aluno_compensacao_fk FOREIGN KEY (compensacao_ausencia_id) REFERENCES compensacao_ausencia(id);

-- Executar ap�s a importa��o das UEs
ALTER TABLE ue 
ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY;

select setval('ue_id_seq', COALESCE((SELECT MAX(id)+1 FROM ue), 1), false); 