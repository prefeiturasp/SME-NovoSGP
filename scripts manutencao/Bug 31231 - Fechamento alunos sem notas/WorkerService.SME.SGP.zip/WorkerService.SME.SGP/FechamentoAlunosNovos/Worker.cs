using Dapper;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FechamentoAlunosNovos
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly ConnectionStrings _connectionStrings;

        public Worker(ILogger<Worker> logger, IOptions<ConnectionStrings> connectionStrings)
        {
            _logger = logger;
            _connectionStrings = connectionStrings != null ? connectionStrings.Value : throw new System.ArgumentNullException(nameof(connectionStrings));
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {

                Console.Write("DRE: ");
                string dre_id = Console.ReadLine();
                //GerarLogTurmaDre($"DRE: {dre_id}"); //LOG

                var stringConexaoD1 = _connectionStrings.EolConnection;
                string stringConexaoSgp = _connectionStrings.SGPPostgres;

                NpgsqlConnection connectionSGP = new NpgsqlConnection(stringConexaoSgp);
                SqlConnection connectionD1 = new SqlConnection(stringConexaoD1);

                var turmas = await connectionSGP.QueryAsync<TurmaDto>(QueriesSGP.ObterTurmasPorDre.ToString(), new { dre_id = dre_id });
                List<TurmaDto> turmasDre = turmas.ToList();

                foreach (TurmaDto turma in turmasDre)
                {
                    var alunos = await connectionD1.QueryAsync<Aluno>(QueriesEOL.ObterAlunosTurma.ToString(), new { codTurma = turma.CodigoTurmaEol });
                    List<Aluno> alunosTurma = alunos.ToList();

                    string codTurmaLog = String.Empty;

                    var ft = await connectionSGP.QueryAsync<FechamentoTurmaDisciplina>(QueriesSGP.ObterFechamentoTurmaDisciplina.ToString(), new { codTurma = Convert.ToInt32(turma.CodigoTurma) });
                    List<FechamentoTurmaDisciplina> fechamentoTurmaDisciplinas = ft.ToList();

                    foreach (FechamentoTurmaDisciplina ftd in fechamentoTurmaDisciplinas)
                    {
                        var retAlunosFtd = await connectionSGP.QueryAsync<string>(QueriesSGP.ObterAlunosFechamentoTurmaDisciplina.ToString(), new { ft_id = ftd.Id });
                        List<string> alunosFtd = retAlunosFtd.ToList();
                        List<Aluno> alunosSemFechamento = alunosTurma.Where(x => !alunosFtd.Contains(x.CodigoAluno)).ToList();

                        if (alunosSemFechamento.Any())
                        {
                            if (String.IsNullOrEmpty(codTurmaLog))
                            {
                                codTurmaLog = turma.CodigoTurmaEol;
                                Notificar($"DRE: {dre_id}, TURMA: {turma.CodigoTurmaEol}");
                                //GerarLogTurmaDre($"TURMA: {turma.CodigoTurmaEol}, DISCIPLINA: {ftd.DisciplinaId}."); //LOG                                    
                            }

                            foreach (Aluno aluno in alunosSemFechamento)
                            {
                                await GeraFechamentoAluno(connectionSGP, turma, ftd, aluno);
                            }
                        }
                    }

                }
                //GerarLogTurmaDre("-------------------------------------------"); //LOG
                await Task.Delay(1000, stoppingToken);
            }
        }

        private async Task GeraFechamentoAluno(NpgsqlConnection connectionSGP, TurmaDto turma, FechamentoTurmaDisciplina ftd, Aluno aluno)
        {
            NpgsqlTransaction transaction = null;
            try
            {
                await connectionSGP.OpenAsync();
                transaction = connectionSGP.BeginTransaction();
                var id = await connectionSGP.QueryAsync<int>(QueriesSGP.InserirFechamentoAluno.ToString(), new { codigoAluno = aluno.CodigoAluno, fechamentoDisciplinaTurmaId = ftd.Id }, transaction);
                int idFechamentoAluno = id.FirstOrDefault();

                if (ftd.PermiteLancamentoNota)
                {
                    if (turma.TipoNota == 1)
                        await connectionSGP.ExecuteAsync(QueriesSGP.InserirNota.ToString(), new { disciplinaId = ftd.DisciplinaId, fechamentoAlunoId = idFechamentoAluno }, transaction);
                    else
                        await connectionSGP.ExecuteAsync(QueriesSGP.InserirConceitoId.ToString(), new { disciplinaId = ftd.DisciplinaId, fechamentoAlunoId = idFechamentoAluno }, transaction);
                }
                else
                {
                    await connectionSGP.ExecuteAsync(QueriesSGP.InserirSinteseId.ToString(), new { disciplinaId = ftd.DisciplinaId, fechamentoAlunoId = idFechamentoAluno }, transaction);
                }

                transaction.Commit();
                await connectionSGP.CloseAsync();
            }
            catch (Exception e)
            {
                if (transaction != null)
                {
                    transaction.Rollback();
                }
                NotificarErro(e, "erro");
            }
        }

        private void NotificarErro(Exception ex, string erro)
        {
            _logger.LogError(ex, erro);
        }

        private void Notificar(string msg)
        {
            _logger.LogInformation(msg);
        }

        private void GerarLogTurmaDre(string linhaLog)
        {
            StreamWriter x;
            string caminhoLog = Path.Combine(Directory.GetCurrentDirectory(), "Log\\LogTurmasDre.txt");
            x = File.AppendText(caminhoLog);
            x.WriteLine(linhaLog);
            x.Close();
        }


    }
}
