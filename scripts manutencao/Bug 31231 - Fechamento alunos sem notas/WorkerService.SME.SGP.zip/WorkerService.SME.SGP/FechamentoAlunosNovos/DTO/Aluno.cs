﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FechamentoAlunosNovos
{
    public class Aluno
    {

        public string CodigoAluno { get; set; }
        public string NomeAluno { get; set; }
        public string DataNascimento { get; set; }
        public string NomeSocialAluno { get; set; }
        public string TurmaCodigo { get; set; }
        public string CodigoSituacaoMatricula { get; set; }
        public string DataSituacao { get; set; }
        public string NumeroAlunoChamada { get; set; }        

    }
}
