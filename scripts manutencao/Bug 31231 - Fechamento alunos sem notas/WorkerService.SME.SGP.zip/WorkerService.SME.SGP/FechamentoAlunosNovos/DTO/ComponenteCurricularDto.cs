﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FechamentoAlunosNovos
{
    public class ComponenteCurricularDto
    {
        public string CodigoComponenteCurricular { get; set; }
    }
}
