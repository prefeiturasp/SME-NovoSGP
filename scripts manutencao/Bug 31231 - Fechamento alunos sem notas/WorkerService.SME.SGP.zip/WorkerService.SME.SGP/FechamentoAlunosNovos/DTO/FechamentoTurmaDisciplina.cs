﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FechamentoAlunosNovos
{
    public class FechamentoTurmaDisciplina
    {        
        public Int32 Id { get; set; }
        public Int32 DisciplinaId { get; set; }
        public bool Ehregencia { get; set; }
        public bool PermiteLancamentoNota { get; set; }
        public Int32 FechamentoTurmaId { get; set; }
    }
}
