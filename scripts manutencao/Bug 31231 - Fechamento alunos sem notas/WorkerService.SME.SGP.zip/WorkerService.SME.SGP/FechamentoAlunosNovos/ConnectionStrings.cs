﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FechamentoAlunosNovos
{
    public class ConnectionStrings
    {
        public string EolConnection
        {
            get
            {
                return Environment.GetEnvironmentVariable("EolConnection");
            }
        }

        public string CoreSSOConnection
        {
            get
            {
                return Environment.GetEnvironmentVariable("CoreSSOConnection");
            }
        }

        public string ApiEolConnection
        {
            get
            {
                return Environment.GetEnvironmentVariable("ApiEolConnection");
            }
        }

        public string SGPPostgres
        {
            get
            {
                return Environment.GetEnvironmentVariable("ConnectionStrings__SGP_Postgres");
            }
        }

        public string SGPPostgresProd
        {
            get
            {
                return Environment.GetEnvironmentVariable("ConnectionStrings__SGP-Postgres-prod");
            }
        }

    }
}
