﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FechamentoAlunosNovos
{
    public static class QueriesSGP
    {
        internal static string ObterTurmasPorDre =>
            @"select t.id as CodigoTurma, t.turma_id CodigoTurmaEol,nccp.tipo_nota TipoNota
                from fechamento_turma_disciplina f
                inner join fechamento_turma ft on ft.id = f.fechamento_turma_id
                inner join turma t on t.id = ft.turma_id
                inner join tipo_ciclo_ano tca on tca.ano = t.ano 
                and tca.modalidade = t.modalidade_codigo
                inner join tipo_ciclo tc on tca.tipo_ciclo_id = tc.id
                inner join notas_conceitos_ciclos_parametos nccp on nccp.ciclo = tc.id
                inner join ue on ue.id = t.ue_id
                inner join dre on dre.id = ue.dre_id
                inner join fechamento_aluno fa on f.id = fa.fechamento_turma_disciplina_id
                where not f.excluido
                and t.ano_letivo = 2020
                and dre.dre_id = @dre_id
                and ft.periodo_escolar_id is null
                group by t.id,t.turma_id,nccp.tipo_nota;";

        internal static string ObterFechamentoTurmaDisciplina =>
            @"select f.id Id, f.disciplina_id DisciplinaId, c.eh_regencia Ehregencia, 
                c.permite_lancamento_nota PermiteLancamentoNota, f.fechamento_turma_id FechamentoTurmaId
                from fechamento_turma_disciplina f
                inner join fechamento_turma ft on ft.id = f.fechamento_turma_id
                inner join componente_curricular c on c.id = f.disciplina_id
                where not f.excluido
                and ft.turma_id = @codTurma
                and ft.periodo_escolar_id is null;";

        internal static string ObterAlunosFechamentoTurmaDisciplina =>
            @"select fa.aluno_codigo
                from fechamento_nota n
                inner join fechamento_aluno fa on fa.id = n.fechamento_aluno_id
                where fa.fechamento_turma_disciplina_id = @ft_id;";

        internal static string ObterFechamentoNotaAluno =>
            @"select n.id
                from fechamento_nota n
                inner join fechamento_aluno fa on fa.id = n.fechamento_aluno_id
                where fa.fechamento_turma_disciplina_id = @ft_id
                and fa.aluno_codigo = @codigoAluno;";

        internal static string InserirFechamentoAluno =>
            @"insert into fechamento_aluno (aluno_codigo, criado_em, criado_por, criado_rf, fechamento_turma_disciplina_id) 
            	values(@codigoAluno, now(), 'SISTEMA', '0', @fechamentoDisciplinaTurmaId) returning id;";

        internal static string InserirNota =>
            @"insert into fechamento_nota (criado_em, criado_por, criado_rf, disciplina_id, nota, fechamento_aluno_id)
    	        values(now(), 'SISTEMA', '0', @disciplinaId,5, @fechamentoAlunoId);";

        internal static string InserirConceitoId =>
            @"insert into fechamento_nota (criado_em, criado_por, criado_rf, disciplina_id, conceito_id, fechamento_aluno_id)
    	        values(now(), 'SISTEMA', '0', @disciplinaId,2, @fechamentoAlunoId);";

        internal static string InserirSinteseId =>
            @"insert into fechamento_nota (criado_em, criado_por, criado_rf, disciplina_id,  fechamento_aluno_id, sintese_id)
    	        values(now(), 'SISTEMA', '0', @disciplinaId,@fechamentoAlunoId, 1);";

    }
}
