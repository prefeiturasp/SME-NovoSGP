﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UpdateAulaAtividadeAvaliativaSGP
{
    public static class QueriesSGP
    {
        internal static string ObterTurmasAulaComponente =>
            @"select a.turma_id as CodigoTurma
                from aula a
                inner join turma t on a.turma_id = t.turma_id
                where t.ano_letivo = @anoLevito                
                and a.disciplina_id = @codigoComponente 
                and a.excluido = false;";

        internal static string UpdateAulas =>
            @"update aula set disciplina_id = '1106' 
                where turma_id = @codigoTurma 
                and disciplina_id = '1046' 
                and excluido = false;";

        internal static string UpdateAtividadesAvaliativas =>
            @"with aad as (
	            select aad.id as aad_id 
	            from atividade_avaliativa a
	            inner join tipo_avaliacao ta on a.tipo_avaliacao_id = ta.id
	            inner join atividade_avaliativa_disciplina aad on aad.atividade_avaliativa_id = a.id
	            where a.excluido = false
	            and ta.situacao = true	
	            and a.turma_id = @codigoTurma
	            and aad.disciplina_id = '1046'
	            and aad.excluido =  false
            )
            update atividade_avaliativa_disciplina set disciplina_id = '1106'
            from aad
            where id = aad.aad_id;";

    }
}
