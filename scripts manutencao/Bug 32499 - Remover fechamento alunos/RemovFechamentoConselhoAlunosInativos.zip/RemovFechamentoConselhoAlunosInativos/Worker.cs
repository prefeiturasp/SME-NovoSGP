using Dapper;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RemovFechamentoConselhoAlunosInativos
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly ConnectionStrings _connectionStrings;

        public Worker(ILogger<Worker> logger, IOptions<ConnectionStrings> connectionStrings)
        {
            _logger = logger;
            _connectionStrings = connectionStrings != null ? connectionStrings.Value : throw new System.ArgumentNullException(nameof(connectionStrings));
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {

                Console.Write("DRE: ");
                string dre_id = Console.ReadLine();

                try
                {
                    var stringConexaoD1 = _connectionStrings.EolConnection;
                    string stringConexaoSgp = _connectionStrings.SGPPostgres;

                    NpgsqlConnection connectionSGP = new NpgsqlConnection(stringConexaoSgp);
                    SqlConnection connectionD1 = new SqlConnection(stringConexaoD1);

                    var turmas = await connectionSGP.QueryAsync<TurmaDto>(QueriesSGP.ObterTurmasPorDre.ToString(), new { dre_id = dre_id });
                    List<TurmaDto> turmasDre = turmas.ToList();

                    foreach (TurmaDto turma in turmasDre)
                    {
                        var alunos = await connectionD1.QueryAsync<Aluno>(QueriesEOL.ObterAlunosInativosTurma.ToString(), new { CodigoTurma = int.Parse(turma.CodigoTurmaEol) });
                        List<Aluno> alunosTurma = alunos.ToList();

                        foreach (Aluno aluno in alunosTurma)
                        {
                            bool conselho = await connectionSGP.QueryFirstOrDefaultAsync<bool>(QueriesSGP.ObterConselhoClasseAluno.ToString(), new { codTurma = Int32.Parse(turma.CodigoTurma), codigoAluno = aluno.CodigoAluno.ToString() });
                            bool fechamento = await connectionSGP.QueryFirstOrDefaultAsync<bool>(QueriesSGP.ObterFechamentoAluno.ToString(), new { codTurma = Int32.Parse(turma.CodigoTurma), codigoAluno = aluno.CodigoAluno.ToString() });
                            if (conselho || fechamento)
                            {
                                Notificar($" TURMA: {turma.CodigoTurma}, ALUNO: {aluno.CodigoAluno} - {aluno.NomeAluno} - {aluno.DataSituacao} - {aluno.CodigoSituacaoMatricula}");
                                await DeleteConselhoClasseFechamentoAluno(connectionSGP, turma.CodigoTurma, aluno.CodigoAluno.ToString());
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    NotificarErro(e, "Erro ");
                }

                await Task.Delay(1000, stoppingToken);
            }
        }

        private async Task DeleteConselhoClasseFechamentoAluno(NpgsqlConnection connectionSGP, string _codTurma, string _codigoAluno)
        {
            NpgsqlTransaction transaction = null;
            try
            {
                await connectionSGP.OpenAsync();
                transaction = connectionSGP.BeginTransaction();

                await connectionSGP.ExecuteAsync(QueriesSGP.DeleteConselhoClasseAluno.ToString(), new { codTurma = Int32.Parse(_codTurma), codigoAluno = _codigoAluno }, transaction);
                await connectionSGP.ExecuteAsync(QueriesSGP.DeleteFechamentoNota.ToString(), new { codTurma = Int32.Parse(_codTurma), codigoAluno = _codigoAluno }, transaction);
                await connectionSGP.ExecuteAsync(QueriesSGP.DeleteFechamentoAluno.ToString(), new { codTurma = Int32.Parse(_codTurma), codigoAluno = _codigoAluno }, transaction);

                transaction.Commit();
                await connectionSGP.CloseAsync();
            }
            catch (Exception e)
            {
                if (transaction != null)
                {
                    transaction.Rollback();
                }
                NotificarErro(e, $" TURMA: {_codTurma}, ALUNO: {_codigoAluno}.");
            }
        }

        private void NotificarErro(Exception ex, string erro)
        {
            _logger.LogError(ex, erro);
        }
        private void Notificar(string msg)
        {
            _logger.LogInformation(msg);
        }

    }
}
