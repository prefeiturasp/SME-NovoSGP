﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RemovFechamentoConselhoAlunosInativos

{
    public class TurmaDto
    {
        public string CodigoTurma { get; set; }
        public string CodigoTurmaEol { get; set; }
        public int TipoNota { get; set; }
    }
}
