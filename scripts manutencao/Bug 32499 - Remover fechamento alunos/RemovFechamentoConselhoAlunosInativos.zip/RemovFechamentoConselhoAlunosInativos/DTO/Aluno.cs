﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RemovFechamentoConselhoAlunosInativos
{
    public class Aluno
    {

        public int CodigoAluno { get; set; }
        public string NomeAluno { get; set; }
        public string DataNascimento { get; set; }
        public string NomeSocialAluno { get; set; }
        public string CodigoSituacaoMatricula { get; set; }
        public string SituacaoMatricula { get; set; }
        public string DataSituacao { get; set; }
        public string DataMatricula { get; set; }
        public string NumeroAlunoChamada { get; set; }        

    }
}
