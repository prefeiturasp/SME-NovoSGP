﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RemovFechamentoConselhoAlunosInativos
{
    public static class QueriesSGP
    {
        internal static string ObterTurmasPorDre =>
            @"select t.id as CodigoTurma, t.turma_id CodigoTurmaEol,nccp.tipo_nota TipoNota
                from fechamento_turma_disciplina f
                inner join fechamento_turma ft on ft.id = f.fechamento_turma_id
                inner join turma t on t.id = ft.turma_id
                inner join tipo_ciclo_ano tca on tca.ano = t.ano 
                and tca.modalidade = t.modalidade_codigo
                inner join tipo_ciclo tc on tca.tipo_ciclo_id = tc.id
                inner join notas_conceitos_ciclos_parametos nccp on nccp.ciclo = tc.id
                inner join ue on ue.id = t.ue_id
                inner join dre on dre.id = ue.dre_id
                inner join fechamento_aluno fa on f.id = fa.fechamento_turma_disciplina_id
                where not f.excluido
                and t.ano_letivo = 2020
                and dre.dre_id = @dre_id
                and ft.periodo_escolar_id is null
                group by t.id,t.turma_id,nccp.tipo_nota;";



        internal static string ObterConselhoClasseAluno =>
            @"select 1 
                from fechamento_turma ft 
                inner join conselho_classe cc on ft.id = cc.fechamento_turma_id
                inner join conselho_classe_aluno cca on cca.conselho_classe_id = cc.id
                where ft.turma_id = @codTurma
                and cca.aluno_codigo = @codigoAluno limit 1;";

        internal static string ObterFechamentoAluno =>
            @"select 1
                from fechamento_nota n
                inner join fechamento_aluno fa on fa.id = n.fechamento_aluno_id
                inner join fechamento_turma_disciplina ftd on ftd.id = fa.fechamento_turma_disciplina_id
                inner join fechamento_turma ft on ft.id = ftd.fechamento_turma_id
                where ft.turma_id = @codTurma 
                and fa.aluno_codigo = @codigoAluno limit 1;";



        internal static string DeleteConselhoClasseAluno =>
            @"delete from conselho_classe_aluno where id in                
                (select cca.id 
                    from fechamento_turma ft 
                    inner join conselho_classe cc on ft.id = cc.fechamento_turma_id
                    inner join conselho_classe_aluno cca on cca.conselho_classe_id = cc.id
                    where ft.turma_id = @codTurma
                    and cca.aluno_codigo = @codigoAluno);";

        internal static string DeleteFechamentoNota =>
            @"delete from fechamento_nota where id in
                (select n.id
                    from fechamento_nota n
                    inner join fechamento_aluno fa on fa.id = n.fechamento_aluno_id
                    inner join fechamento_turma_disciplina ftd on ftd.id = fa.fechamento_turma_disciplina_id
                    inner join fechamento_turma ft on ft.id = ftd.fechamento_turma_id
                    where ft.turma_id = @codTurma 
                    and fa.aluno_codigo = @codigoAluno);";

        internal static string DeleteFechamentoAluno =>
            @"delete from fechamento_aluno where id in
                (select fa.id
                    from fechamento_nota n
                    inner join fechamento_aluno fa on fa.id = n.fechamento_aluno_id
                    inner join fechamento_turma_disciplina ftd on ftd.id = fa.fechamento_turma_disciplina_id
                    inner join fechamento_turma ft on ft.id = ftd.fechamento_turma_id
                    where ft.turma_id = @codTurma 
                    and fa.aluno_codigo = @codigoAluno);";

    }
}
