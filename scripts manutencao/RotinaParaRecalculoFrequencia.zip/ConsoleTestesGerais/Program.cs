﻿using Dapper;
using Microsoft.ApplicationInsights;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using SME.SGP.Aplicacao.Integracoes;
using SME.SGP.Dados.Mapeamentos;
using SME.SGP.Dominio.Interfaces;
using SME.SGP.Infra;
using SME.SGP.IoC;
using System;
using System.Configuration;
using System.Linq;
using System.Text;

namespace ConsoleTestesGerais
{
    class Program
    {

        static void Main(string[] args)
        {

            IConfiguration configuration = new ConfigurationBuilder()
                .AddEnvironmentVariables()
                .Build();

            var services = new ServiceCollection()
                .AddSingleton(configuration)
                .AddHttpContextAccessor();

            services.AddHttpClient<IServicoEOL, ServicoEOL>(c =>
            {
                c.BaseAddress = new Uri(configuration.GetSection("UrlApiEOL").Value);
                c.DefaultRequestHeaders.Add("Accept", "application/json");
            });

            services.AddDistributedRedisCache(options =>
            {
                options.Configuration = configuration.GetConnectionString("SGP-Redis");
                options.InstanceName = configuration.GetValue<string>("Nome-Instancia-Redis");
            });

            RegistraDependencias.Registrar(services);
            RegistrarMapeamentos.Registrar();

            services
                .AddSingleton<IServicoLog>(new ServicoLog(configuration, new TelemetryClient()));

            var serviceProvider = services.BuildServiceProvider();
            var calculoFerquencia = serviceProvider.GetService<IServicoCalculoFrequencia>();

            var stringConexao = "User ID=postgres;Password=Z7LfhyT0XqrpZSi3;Host=10.50.1.142;Port=5432;Database=sgp_db;Pooling=true;";

            using (NpgsqlConnection connection = new NpgsqlConnection(stringConexao))
            {
                var query = new StringBuilder();

                query.AppendLine("select fab.*");
                query.AppendLine("	from frequencia_aluno_sem_periodo_escolar_bkp fab");
                query.AppendLine("		left join frequencia_aluno fa");
                query.AppendLine("			on fab.codigo_aluno = fa.codigo_aluno and");
                query.AppendLine("			   fab.tipo = fa.tipo and");
                query.AppendLine("			   fab.disciplina_id = fa.disciplina_id and");
                query.AppendLine("			   fab.periodo_inicio  = fa.periodo_inicio and");
                query.AppendLine("			   fab.periodo_fim = fa.periodo_fim");
                query.AppendLine("where fa.id is null");
                query.AppendLine("  and fab.calculada = false");
                query.AppendLine("  and fab.turma_id is not null");
                query.AppendLine("  and exists (select 1");
                query.AppendLine("	        	    from periodo_escolar pe");
                query.AppendLine("				where pe.periodo_inicio = fab.periodo_inicio and");
                query.AppendLine("				 	  pe.periodo_fim  = fab.periodo_fim)");
                query.AppendLine("order by fab.turma_id,");
                query.AppendLine("    	   fab.codigo_aluno,");
                query.AppendLine("	       fab.tipo;");
                

                var dados = connection.Query<FrequenciaAlunoSemCalculo>(query.ToString());
                var listaTurmasDisciplinas = dados
                    .Where(x => !string.IsNullOrWhiteSpace(x.disciplina_id))
                    .Select(x => new { x.turma_id, x.disciplina_id })
                    .Distinct()
                    .ToList();

                var alunosComDisciplina = dados.Where(y => !string.IsNullOrWhiteSpace(y.disciplina_id)).Select(z => z.codigo_aluno).Distinct().ToList();
                var alunosSemDiscplina = dados.Where(x => string.IsNullOrWhiteSpace(x.disciplina_id)).Select(x => x.codigo_aluno).Distinct().ToList();
                var alunosDesconsiderados = alunosSemDiscplina.Except(alunosComDisciplina).Distinct().ToList();

                listaTurmasDisciplinas.ForEach(x =>
                {
                    var frequenciaTurma = dados.Where(ft => ft.turma_id.Equals(x.turma_id) && ft.disciplina_id.Equals(x.disciplina_id)).ToList();
                    var codigosAluno = frequenciaTurma.Select(ft => ft.codigo_aluno).Distinct().ToList();
                    try
                    {
                        calculoFerquencia.CalcularFrequenciaPorTurma(codigosAluno.ToArray(), frequenciaTurma.First().periodo_inicio.AddDays(1), x.turma_id, x.disciplina_id);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        Console.ReadLine();
                    }
                });

                alunosDesconsiderados.ForEach(x =>
                {
                    var frequenciaAluno = dados.Where(fa => fa.codigo_aluno.Equals(x));
                    try
                    {
                        calculoFerquencia.CalcularFrequenciaPorTurma(new string[] { x }, frequenciaAluno.First().periodo_inicio.AddDays(1), frequenciaAluno.First().turma_id, string.Empty);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        Console.ReadLine();
                    }
                });

                Console.WriteLine("Fim");
                Console.ReadLine();
            }
        }
    }
}
