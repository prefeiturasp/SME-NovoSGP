﻿using System;

namespace ConsoleTestesGerais
{
    public class FrequenciaAlunoSemCalculo
    {
        public long id { get; set; }
        public string codigo_aluno { get; set; }
        public int tipo { get; set; }
        public string disciplina_id { get; set; }
        public DateTime periodo_inicio { get; set; }
        public DateTime periodo_fim { get; set; }
        public int bimestre { get; set; }
        public int total_aulas { get; set; }
        public int total_ausencias { get; set; }
        public DateTime criado_em { get; set; }
        public string criado_por { get; set; }
        public DateTime alterado_em { get; set; }
        public string alterado_por { get; set; }
        public string criado_rf { get; set; }
        public string alterado_rf { get; set; }
        public bool excluido { get; set; }
        public bool migrado { get; set; }
        public int total_compensacoes { get; set; }
        public string turma_id { get; set; }
        public long? periodo_escolar_id { get; set; }
    }
}
