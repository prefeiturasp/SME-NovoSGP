﻿using System;

namespace WorkerServiceAjusteDuplicidadesAusencias
{
    public class DadosDuplicidadeAusenciaDto
    {
        public string CodigoAluno { get; set; }
        public DateTime DataAula { get; set; }
        public long DisciplinaId { get; set; }
        public string TurmaId { get; set; }
        public int NumeroAula { get; set; }
        public int Quantidade { get; set; }
    }
}
