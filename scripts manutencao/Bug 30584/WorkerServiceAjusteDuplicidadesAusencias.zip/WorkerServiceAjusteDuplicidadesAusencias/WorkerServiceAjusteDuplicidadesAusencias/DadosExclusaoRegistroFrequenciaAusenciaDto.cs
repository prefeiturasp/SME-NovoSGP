﻿namespace WorkerServiceAjusteDuplicidadesAusencias
{
    public class DadosExclusaoRegistroFrequenciaAusenciaDto
    {
        public long RegistroAusenciaId { get; set; }
        public long RegistroFrequenciaId { get; set; }
    }
}
