using Dapper;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WorkerServiceAjusteDuplicidadesAusencias
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;

        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                Console.Write("Ano inicial: ");
                var anoInicial = Console.ReadLine();

                Console.Write("Ano final: ");
                var anoFinal = Console.ReadLine();

                Console.Write("DRE: ");
                var dreId = Console.ReadLine();

                Console.Write("Bimestre: ");
                var bimestre = Convert.ToInt32(Console.ReadLine());

                var stringConexaoSgp = "User ID=postgres;Password=Z7LfhyT0XqrpZSi3;Host=10.50.1.142;Port=5432;Database=sgp_db;Pooling=true;";

                var sqlQuery = new StringBuilder();
                sqlQuery.AppendLine("select codigo_aluno CodigoAluno,");
                sqlQuery.AppendLine("       data_aula DataAula,");
                sqlQuery.AppendLine("       disciplina_id DisciplinaId,");
                sqlQuery.AppendLine("       turma_id TurmaId,");
                sqlQuery.AppendLine("       numero_aula NumeroAula,");
                sqlQuery.AppendLine("       qtde Quantidade");
                sqlQuery.AppendLine("from f_registros_ausencias_duplicadas(@anoAtual, @ueId, @bimestre);");

                var sqlQuery2 = new StringBuilder();
                sqlQuery2.AppendLine("select id RegistroAusenciaId,");
                sqlQuery2.AppendLine("	     registro_frequencia_id RegistroFrequenciaId");
                sqlQuery2.AppendLine("	from (select row_number() over (partition by numero_aula order by 3, 4) linha,");
                sqlQuery2.AppendLine("		   	     raa.id,");
                sqlQuery2.AppendLine("		   		 raa.registro_frequencia_id");
                sqlQuery2.AppendLine("		  	from registro_ausencia_aluno raa");
                sqlQuery2.AppendLine("		  		inner join registro_frequencia rf");
                sqlQuery2.AppendLine("					on raa.registro_frequencia_id = rf.id");
                sqlQuery2.AppendLine("				inner join aula a");
                sqlQuery2.AppendLine("					on rf.aula_id = a.id");
                sqlQuery2.AppendLine("		  where raa.codigo_aluno = @codigoAluno and");
                sqlQuery2.AppendLine("		  	    a.data_aula::date = @dataAula::date and");
                sqlQuery2.AppendLine("		  		a.disciplina_id = @codigoDisciplina and");
                sqlQuery2.AppendLine("		  		a.turma_id = @turmaId) a");
                sqlQuery2.AppendLine("where linha <> 1;");

                using (NpgsqlConnection connection = new NpgsqlConnection(stringConexaoSgp))
                {
                    await connection.OpenAsync();

                    NpgsqlTransaction transaction;

                    for (int anoAtual = Convert.ToInt32(anoInicial); anoAtual < Convert.ToInt32(anoFinal) + 1; anoAtual++)
                    {
                        var ues = await connection
                             .QueryAsync<long>($"select ue.id from ue inner join dre on ue.dre_id = dre.id where dre.dre_id = @dreId order by ue.ue_id;", new { dreId });

                        foreach (var ueId in ues)
                        {
                            try
                            {
                                var dadosExclusao = await connection.QueryAsync<DadosDuplicidadeAusenciaDto>(sqlQuery.ToString(), new
                                {
                                    anoAtual,
                                    ueId,
                                    bimestre
                                }, commandTimeout: 300);

                                foreach (var registro in dadosExclusao)
                                {
                                    var registrosExclusao = await connection.QueryAsync<DadosExclusaoRegistroFrequenciaAusenciaDto>(sqlQuery2.ToString(), new
                                    {
                                        codigoAluno = registro.CodigoAluno,
                                        dataAula = registro.DataAula,
                                        codigoDisciplina = registro.DisciplinaId.ToString(),
                                        turmaId = registro.TurmaId
                                    });

                                    var idsRegistrosAusenciaExclusao = registrosExclusao
                                        .Select(x => x.RegistroAusenciaId)
                                        .Distinct().ToList();

                                    var idsRegistrosFrequenciaExclusao = registrosExclusao
                                        .Select(x => x.RegistroFrequenciaId)
                                        .Distinct().ToList();

                                    transaction = connection.BeginTransaction();

                                    try
                                    {
                                        await connection.ExecuteAsync("delete from registro_ausencia_aluno where id = any(@ids);",
                                            new { ids = idsRegistrosAusenciaExclusao }, transaction);

                                        var rfExc = await connection.ExecuteAsync("delete from registro_frequencia rf where rf.id = any(@ids) and not exists (select 1 from registro_ausencia_aluno raa where raa.registro_frequencia_id = rf.id);",
                                            new { ids = idsRegistrosFrequenciaExclusao }, transaction);

                                        await transaction.CommitAsync();

                                        _logger.LogInformation($"Exclus�o: reg. aus.: {string.Join(", ", idsRegistrosAusenciaExclusao)} - reg. freq.: {(rfExc > 0 ?  string.Join(", ", idsRegistrosFrequenciaExclusao) : string.Empty)}");

                                    }
                                    catch (Exception ex)
                                    {
                                        transaction.Rollback();
                                        _logger.LogError(ex, $"Erro ao excluir: reg. aus.: {string.Join(", ", idsRegistrosAusenciaExclusao)} - reg. freq.: {string.Join(", ", idsRegistrosFrequenciaExclusao)}");
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, $"Erro - Ano Letivo: {anoAtual} UE: {ueId} Bimestre: {bimestre}");
                            }
                        }
                    }
                }

                await Task.Delay(1000, stoppingToken);
            }
        }
    }
}
